var exports = module.exports = {};

exports.config = {
  bucket: {
    dev: 'rac-dev-devops1',
    qa: 'rac-qa-devops',
    uat: 'rac-uat-devops',
    breakfix: 'rac-breakfix-devops',
    prod: 'rac-prod-devops-1'
  }
};
