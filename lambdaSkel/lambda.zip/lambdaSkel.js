S3 = require('aws-sdk/clients/s3');
KMS = require('aws-sdk/clients/kms');
config = require('./properties.js');

var getEnv = function(c) {

};

var handler = function(e, c, cb) {
  var s3 = new AWS.S3();
  // s3.copyObject({
  // 	Bucket: 
  // })
  cb(null, [e, c]);
}

module.exports = {
  handler: handler
}; 
